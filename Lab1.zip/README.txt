1. Gordon Moore
2. I had to relearn CASE, as well as for the extra credit, figuring out how to find the date and time was difficult because it wasn't in the slides (IDK why I looked there first rather than googling)
3. I liked how straightforward each query question was, it was really easy just to go from plain english to SQL because of the wording.
4. I spent about 2 hours, mostly doing research on more obscure stuff or browsing the lecture slides.
5. Not really sure, I was really only looking for the stuff I needed for the assignment.
