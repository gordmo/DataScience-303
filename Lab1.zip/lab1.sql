-- 1
SELECT known_for FROM pioneer WHERE first = 'Jim' AND last = 'Melton';
-- 2
SELECT first, last, known_for FROM pioneer WHERE last LIKE 'S%' AND first NOT LIKE 'M%';
-- 3
SELECT first || ' ' || last AS name, birth, known_for FROM pioneer WHERE death IS NULL ORDER BY birth ASC;
-- 4
SELECT first || ' ' || last AS name, death - birth AS age, death FROM pioneer WHERE death IS NOT NULL ORDER BY age DESC;
-- 5
SELECT name AS organization, database_contributions AS contribution FROM organization WHERE database_contributions ILIKE '%developing%' ORDER BY organization ASC;
-- 6
SELECT DISTINCT role FROM pioneer_org_xref ORDER BY role ASC;
-- 7
SELECT organization.name, organization.database_contributions FROM organization WHERE organization.founded >= 1890 AND organization.founded <= 1960 ORDER BY organization.founded ASC;
-- 8
SELECT first || ' ' || last AS name, 
        CASE
            WHEN death IS NOT NULL THEN death - birth
            WHEN death IS NULL THEN 2023 - birth
        END AS age
        FROM pioneer
        ORDER BY age ASC;
-- 9 JOINS \/
SELECT pioneer.first, pioneer.last FROM pioneer, pioneer_org_xref WHERE pioneer.id = pioneer_org_xref.pioneer_id AND pioneer_org_xref.role = 'Computer Scientist' ORDER BY pioneer.birth ASC;
-- 10
SELECT pioneer.first || ' ' || pioneer.last AS name, turing_award.year_awarded, turing_award.awarded_for FROM pioneer, turing_award WHERE pioneer.id = turing_award.pioneer_id ORDER BY name ASC;
-- 11
SELECT pioneer.last || ', ' || pioneer.first AS name FROM pioneer, pioneer_org_xref WHERE pioneer.id = pioneer_org_xref.pioneer_id AND pioneer_org_xref.organization_id = 1 ORDER BY pioneer.last ASC, pioneer.first ASC;
-- 12
SELECT pioneer.first || ' ' || pioneer.last AS name FROM pioneer, organization, pioneer_org_xref WHERE pioneer.id = pioneer_org_xref.pioneer_id AND pioneer_org_xref.organization_id = organization.id AND pioneer_org_xref.role ILIKE '%co-founder%' ORDER BY pioneer.birth DESC LIMIT 1; 
-- 13 EC \/
SELECT EXTRACT(HOUR FROM NOW()) AS hour, EXTRACT(MINUTE FROM NOW()) AS minute, EXTRACT(SECOND FROM NOW()) AS second;
-- 14
SELECT pioneer.first || ' ' || pioneer.last AS name, organization.name AS organization FROM pioneer, organization, pioneer_org_xref, turing_award WHERE pioneer.id = pioneer_org_xref.pioneer_id AND pioneer_org_xref.organization_id = organization.id AND pioneer.id = turing_award.pioneer_id ORDER BY name ASC, organization ASC;