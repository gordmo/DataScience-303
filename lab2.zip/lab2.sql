/*
    CSCI 403 Lab 2: Schedule
    
    Name: Gordon Moore
*/

-- do not put SET SEARCH_PATH in this file
-- add your statements after the appropriate Step item
-- it's fine to add additional comments as well

/* Step 1: Create the table */
DROP TABLE IF EXISTS schedule CASCADE;
CREATE TABLE schedule (
    department TEXT,
    course TEXT,
    title TEXT NOT NULL,
    credits NUMERIC(3,1) NOT NULL,
    semester TEXT CHECK (semester IN ('fall', 'spring', 'summer')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    PRIMARY KEY (department, course)
);

/* Step 2: Insert the data */
-- public.cs_courses
-- department, course_number, course_title, semester_hours, fall (boolean), spring (boolean), summer (boolean)
INSERT INTO schedule (department, course, title, credits, semester)
SELECT 'CSCI', course_number, course_title, semester_hours,
CASE 
  WHEN fall = true THEN 'fall'
  WHEN spring = true THEN 'spring'
  WHEN summer = true THEN 'summer'
  ELSE NULL
END
FROM public.cs_courses
WHERE course_number = '290' OR course_number = '303' OR course_number = '358' OR course_number = '403';

INSERT INTO schedule (department, course, title, credits, semester)
SELECT SUBSTRING(course_id, 1, 4), SUBSTRING(course_id, 5), title, 3, 'fall'
FROM mines_courses
WHERE course_id LIKE 'MATH201' AND section = 'E';

/* Step 3: Fix errors */
UPDATE schedule SET semester = 'spring' WHERE semester IS NULL;
UPDATE schedule SET title = 'DATABASE MANAGEMENT' WHERE course = '403';

/* Step 4: Add more constraints */
ALTER TABLE schedule ADD CONSTRAINT title_unique UNIQUE (title);
ALTER TABLE schedule ADD CONSTRAINT credits_check CHECK (credits >= .5 AND credits <= 15) WHERE credits IS NOT NULL;

/* Step 5: Create another table */
DROP TABLE IF EXISTS assumed_grades CASCADE;
CREATE TABLE assumed_grades (
    term TEXT CHECK (term IN ('fall', 'spring', 'summer')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    department TEXT,
    course TEXT,
    title TEXT NOT NULL,
    grade CHAR(3),
    credits NUMERIC(3,1),
    PRIMARY KEY (term, year, department, course),
    FOREIGN KEY (department, course) REFERENCES schedule (department, course)
);
ALTER TABLE assumed_grades ADD FOREIGN KEY (department, course) REFERENCES schedule(department, course);

/* Step 6: Add the data */
INSERT INTO assumed_grades (term, department, course, title, credits)
SELECT 'fall', department, course_number, course_title, semester_hours
FROM public.cs_courses;


/* Step 7: Enter grades */
UPDATE assumed_grades SET grade = 'A';

/* Step 8: cleaning up the table */
ALTER TABLE assumed_grades RENAME COLUMN term TO semester;

/* Step 9 (Extra Credit): Play */
-- Going to try and add a class I haven't taken (not in schedule) to assumed_grades
INSERT INTO assumed_grades (semester, department, course, title,grade, credits)
VALUES ('fall', 'CSCI', '262', 'DATA STRUCTURES AND ALGORITHMS','INC', 3);
-- error code
-- insert or update on table "assumed_grades" violates foreign key constraint "assumed_grades_department_course_fkey"

-- Another update that fails due to the foreign key constraint
UPDATE assumed_grades SET course = '262' WHERE course = '290';
-- violates because 262 is not in the schedule table

/* Step 10: Make a new table by copying */
CREATE TABLE transcript AS SELECT * FROM assumed_grades;
ALTER TABLE transcript ADD CONSTRAINT transcript_fk FOREIGN KEY (department, course) REFERENCES schedule (department, course);
UPDATE transcript SET grade = 'A+' WHERE course = '403';

/* Step 11 (Extra Credit): Re-examining the schema */
ALTER TABLE assumed_grades DROP CONSTRAINT assumed_grades_department_course_fkey;
ALTER TABLE schedule DROP CONSTRAINT schedule_pkey;
ALTER TABLE schedule ADD PRIMARY KEY (department, course, semester, year);
ALTER TABLE assumed_grades ADD CONSTRAINT assumed_grades_fk FOREIGN KEY (department, course, semester, year) REFERENCES schedule (department, course, semester, year);

INSERT INTO schedule (department, course, title, credits, semester, year)
SELECT 'CSCI', course_number, course_title, semester_hours,
CASE 
  WHEN fall = true THEN 'fall'
  WHEN spring = true THEN 'spring'
  WHEN summer = true THEN 'summer'
  ELSE NULL
END,
2024
FROM public.cs_courses
WHERE course_number = '306' OR course_number = '404' OR course_number = '406';

INSERT INTO schedule (department, course, title, credits, semester, year)
VALUES ('PHGN', '200', 'PHYSICS II-ELCTRMGT/OPTC (SC1)', 3, 'spring', 2024), ('CHGN', '122', 'PRIN OF CHEMISTRY II (SC1)', 3, 'spring', 2024);
