1. Gordon Moore
2. I really struggled with adding foreign keys, but I realized I was just referencing the wrong table each time.
3. I liked the step by step nature, rather than just saying "make this table" we had steps for each part of the creation of the table.
4. About 2 hours.