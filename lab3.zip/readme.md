1. Gordon Moore
2. I really struggled with the erd diagram, ensuring that I actually hit all of the requirements.
3. I liked building a whole schema* from scratch
4. I spent about 3.5 hours on this one.