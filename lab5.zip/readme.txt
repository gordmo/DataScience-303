Gordon Moore
I really struggled with the Amy Ray one, but only because it required so many joins.
I liked learning more about subqueries, I think they're super powerful
I spent about 4.5 hours on this assignment.